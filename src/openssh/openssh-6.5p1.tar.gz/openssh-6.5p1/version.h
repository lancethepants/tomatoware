/* $OpenBSD: version.h,v 1.69 2014/01/16 07:32:00 djm Exp $ */

#define SSH_VERSION	"OpenSSH_6.5"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
