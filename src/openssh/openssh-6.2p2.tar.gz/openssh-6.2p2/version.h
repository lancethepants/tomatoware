/* $OpenBSD: version.h,v 1.66 2013/02/10 21:19:34 markus Exp $ */

#define SSH_VERSION	"OpenSSH_6.2"

#define SSH_PORTABLE	"p2"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
