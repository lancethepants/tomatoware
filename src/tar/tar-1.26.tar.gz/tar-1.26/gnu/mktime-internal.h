/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#include <time.h>
time_t mktime_internal (struct tm *,
                        struct tm * (*) (time_t const *, struct tm *),
                        time_t *);
