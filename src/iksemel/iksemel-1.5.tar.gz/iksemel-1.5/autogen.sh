#!/bin/sh
# Run this to generate the configure script.

srcdir=`dirname $0`

echo "Running libtoolize..."
libtoolize --copy --force --automake

echo "Running aclocal..."
aclocal

echo "Running autoheader..."
autoheader

echo "Running automake..."
automake --add-missing --gnu --include-deps

echo "Running autoconf..."
autoconf

echo 
echo "Done!"
echo "Now run $srcdir/configure in order to create Makefiles."
echo
