#define RARVER_MAJOR     6
#define RARVER_MINOR    20
#define RARVER_BETA      1
#define RARVER_DAY      25
#define RARVER_MONTH    10
#define RARVER_YEAR   2022
