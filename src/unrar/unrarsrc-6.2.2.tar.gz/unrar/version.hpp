#define RARVER_MAJOR     6
#define RARVER_MINOR    20
#define RARVER_BETA      2
#define RARVER_DAY      12
#define RARVER_MONTH    11
#define RARVER_YEAR   2022
