#define RARVER_MAJOR     5
#define RARVER_MINOR    10
#define RARVER_BETA      2
#define RARVER_DAY       5
#define RARVER_MONTH     4
#define RARVER_YEAR   2014
