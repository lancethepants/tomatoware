#include<lib.h>
#include<stdio.h>
int main(void)
{
  char *t = meson_print();
  printf("%s", t);
  return 0;
}
