#ifndef PCH_ONE
#define PCH_ONE
#include<stdio.h>
#endif
