int func1_in_obj(void);
int func2_in_obj(void);
int func3_in_obj(void);
int func4_in_obj(void);
int func5_in_obj(void);
int func6_in_obj(void);

int main(void) {
    return func1_in_obj() + func2_in_obj() + func3_in_obj()
         + func4_in_obj() + func5_in_obj() + func6_in_obj();
}
