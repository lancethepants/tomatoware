{
  dll => { MAJOR => 0, MINOR => 4, PATCH => 2 },
  ext => { MAJOR => 0, MINOR => 4, PATCH => 2 }, 
  lib => { MAJOR => 0, MINOR => 4, PATCH => 2 }, 
}

