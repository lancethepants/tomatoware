#include "crypto_int16.h"
#include "signed.h"
DOIT(16,crypto_int16)
