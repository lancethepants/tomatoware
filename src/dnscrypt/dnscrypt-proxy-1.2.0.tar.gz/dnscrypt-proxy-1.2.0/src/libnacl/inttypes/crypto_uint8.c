#include "crypto_uint8.h"
#include "unsigned.h"
DOIT(8,crypto_uint8)
