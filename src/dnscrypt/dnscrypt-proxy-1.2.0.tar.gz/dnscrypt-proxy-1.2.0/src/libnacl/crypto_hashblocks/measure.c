#include "crypto_hashblocks.h"

const char *primitiveimplementation = crypto_hashblocks_IMPLEMENTATION;
const char *implementationversion = crypto_hashblocks_VERSION;
const char *sizenames[] = { "statebytes", 0 };
const long long sizes[] = { crypto_hashblocks_STATEBYTES };

void preallocate(void)
{
}

void allocate(void)
{
}

void measure(void)
{
}
