#include "crypto_verify.h"

const char *primitiveimplementation = crypto_verify_IMPLEMENTATION;
const char *implementationversion = crypto_verify_VERSION;
const char *sizenames[] = { "inputbytes", 0 };
const long long sizes[] = { crypto_verify_BYTES };

void preallocate(void)
{
}

void allocate(void)
{
}

void measure(void)
{
}
