
#ifndef __PID_FILE_H__
#define __PID_FILE_H__ 1

int pid_file_create(const char * const pid_file, const _Bool will_chroot);

#endif
