
$l2h_cache_key = q/
This is some \LaTeX{}/;
$l2h_cache{$l2h_cache_key} = q|
<P>
This is some <SPAN CLASS="logo,LaTeX">L<SUP><SMALL>A</SMALL></SUP>T<SMALL>E</SMALL>X</SPAN>|;
1;