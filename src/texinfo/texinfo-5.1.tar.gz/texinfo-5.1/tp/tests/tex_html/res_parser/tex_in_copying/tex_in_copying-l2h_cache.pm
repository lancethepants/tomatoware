
$l2h_cache_key = q/$$
2 a = \dot{\phi}
$$/;
$l2h_cache{$l2h_cache_key} = q|<BR><P></P>
<DIV ALIGN="CENTER" CLASS="mathdisplay">
<!-- MATH
 \begin{displaymath}
2 a = \dot{\phi}
\end{displaymath}
 -->

<IMG
 WIDTH="100" HEIGHT="20" BORDER="0"
 SRC="tex_in_copying_2.png"
 ALT="\begin{displaymath}
2 a = \dot{\phi}
\end{displaymath}">
</DIV>
<BR CLEAR="ALL">
<P></P>|;

$l2h_cache_key = q/From @ someone <> !
$$
a = \phi
$$/;
$l2h_cache{$l2h_cache_key} = q|From @ someone &lt;&gt; !
<BR><P></P>
<DIV ALIGN="CENTER" CLASS="mathdisplay">
<!-- MATH
 \begin{displaymath}
a = \phi
\end{displaymath}
 -->

<IMG
 WIDTH="100" HEIGHT="20" BORDER="0"
 SRC="tex_in_copying_1.png"
 ALT="\begin{displaymath}
a = \phi
\end{displaymath}">
</DIV>
<BR CLEAR="ALL">
<P></P>|;
1;