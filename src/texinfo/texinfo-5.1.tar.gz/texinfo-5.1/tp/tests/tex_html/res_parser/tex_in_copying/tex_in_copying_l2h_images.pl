# LaTeX2HTML
# Associate images original text with physical files.


$key = q/{displaymath}2a=dot{phi}{displaymath};MSF=1.5;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="20" BORDER="0"
 SRC="|."$dir".q|tex_in_copying_l2h_img2.png"
 ALT="\begin{displaymath}
2 a = \dot{\phi}
\end{displaymath}">|; 

$key = q/{displaymath}a=phi{displaymath};MSF=1.5;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="20" BORDER="0"
 SRC="|."$dir".q|tex_in_copying_l2h_img1.png"
 ALT="\begin{displaymath}
a = \phi
\end{displaymath}">|; 

1;

