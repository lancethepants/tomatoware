#includenext "incnext.h"
#include <angle.c>
#include "quote.c"
 # include \
    /* comment */ "quote1\
.c"
#include "foo.h" // in dfoo

