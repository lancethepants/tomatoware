Now baz/y.h
#ifndef baz_y_h
  #define baz_y_h
  #include y.h
#endif

