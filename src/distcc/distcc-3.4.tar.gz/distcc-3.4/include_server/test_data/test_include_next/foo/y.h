Now: foo/y.h
#include_next "y.h"
